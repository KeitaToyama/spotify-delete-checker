import { supabase } from "../../../lib/supabase";
import { getSession } from "next-auth/react";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  const session = await getSession({ req });
  if (!session) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const { tracks } = req.body;
  if (!tracks || !Array.isArray(tracks)) {
    return res.status(400).json({ error: "Invalid request body" });
  }

  try {
    const { data, error } = await supabase
      .from("Track")
      .insert(
        tracks.map((track) => ({
          user: session.user.name, // Spotifyのユーザー名
          name: track.name,
          artist: track.artist,
          album: track.album,
          url: track.url,
          playlistId: track.playlistId,
          isPlayable: track.isPlayable,
          image_url: track.image_url,
        }))
      )
      .select();

    if (error) throw error;

    return res
      .status(200)
      .json({ message: "Tracks uploaded successfully", data });
  } catch (error) {
    console.error("Database error:", error.message);
    return res.status(500).json({ error: "Internal server error" });
  }
}
