__turbopack_load_page_chunks__("/_error", [
  "static/chunks/[root of the server]__73499ecc._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_beb00741._.js",
  "static/chunks/[root of the server]__ca38f087._.js",
  "static/chunks/src_pages__error_5771e187._.js",
  "static/chunks/src_pages__error_bac399eb._.js"
])
