__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_eb81a647._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_4db64184._.js",
  "static/chunks/[root of the server]__39d10e60._.js",
  "static/chunks/src_styles_globals_4738091e.css",
  "static/chunks/src_pages__app_5771e187._.js",
  "static/chunks/src_pages__app_2804cb82._.js"
])
