__turbopack_load_page_chunks__("/api/auth/[...nextauth]", [
  "static/chunks/node_modules_next_20c65739._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_4db64184._.js",
  "static/chunks/[root of the server]__90aa7765._.js",
  "static/chunks/[root of the server]__3cab321b._.css",
  "static/chunks/src_pages_index_5771e187._.js",
  "static/chunks/src_pages_index_ea8ce760._.js"
])
