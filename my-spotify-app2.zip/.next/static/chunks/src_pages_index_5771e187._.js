(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_index_5771e187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_index_5771e187._.js",
  "chunks": [
    "static/chunks/node_modules_next_20c65739._.js",
    "static/chunks/node_modules_react-dom_82bb97c6._.js",
    "static/chunks/node_modules_4db64184._.js",
    "static/chunks/[root of the server]__90aa7765._.js",
    "static/chunks/[root of the server]__3cab321b._.css"
  ],
  "source": "entry"
});
